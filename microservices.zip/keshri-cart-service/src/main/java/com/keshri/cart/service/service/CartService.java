package com.keshri.cart.service.service;

import com.keshri.cart.service.entity.Cart;
import com.keshri.cart.service.model.CommonClientRequest;
import com.keshri.cart.service.model.CommonClientResponse;

public interface CartService {

    CommonClientResponse addToCart(CommonClientRequest commonClientRequest);

    CommonClientResponse doShopping(CommonClientRequest commonClientRequest);

    CommonClientResponse getCartByUserId(long userId);
}
