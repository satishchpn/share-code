package com.keshri.cart.service.serviceImpl;

import com.keshri.cart.service.entity.Cart;
import com.keshri.cart.service.feignClient.PaymentServiceClient;
import com.keshri.cart.service.model.CommonClientRequest;
import com.keshri.cart.service.model.CommonClientResponse;
import com.keshri.cart.service.repository.CartRepository;
import com.keshri.cart.service.service.CartService;
import com.keshri.cart.service.utils.CommonUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

    final CartRepository cartRepository;

    final PaymentServiceClient paymentServiceClient;

    @Autowired
    public CartServiceImpl(CartRepository cartRepository, PaymentServiceClient paymentServiceClient) {
        this.cartRepository = cartRepository;
        this.paymentServiceClient = paymentServiceClient;
    }

    @Override
    public CommonClientResponse addToCart(CommonClientRequest commonClientRequest) {
        Cart cart = new Cart(RandomUtils.nextInt(), "Laptop", 53000, commonClientRequest.getUserId(), commonClientRequest.getUserName(), new Date());
        if (null != cartRepository.save(cart)) {
            return CommonUtils.returnCommonClientResponse("Success", "200", "Item Added to Cart Successfully with CartId :" + cart.getCartId(), cart);
        } else {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "Failed to add Cart", null);
        }
    }

    @Override
    public CommonClientResponse doShopping(CommonClientRequest commonClientRequest) {
        logger.info("CartServiceImpl - doShopping(-) Called");
        List<Cart> cartList = cartRepository.findByCartIdAndUserId(commonClientRequest.getCartId(), commonClientRequest.getUserId());
        CommonClientResponse commonClientResponse = new CommonClientResponse();
        if (null == cartList || cartList.isEmpty()) {
            logger.error("No Cart detail available for the given details");
            return CommonUtils.returnCommonClientResponse("Failed", "500", "No Cart Details Available for UserId :" + commonClientRequest.getUserId(), null);
        } else {
            logger.info("CartServiceImpl - PaymentServiceClient.doPayment(-) Calling");
            ResponseEntity<CommonClientResponse> response = paymentServiceClient.doPayment(commonClientRequest);
            if (null != response.getBody().getStatusCode() && response.getBody().getStatusCode().equals("200")) {
                return CommonUtils.returnCommonClientResponse("Success", "200", response.getBody().getMessage(), response.getBody().getResponseData());
            } else {
                return CommonUtils.returnCommonClientResponse("Failed", "500", response.getBody().getMessage(), response.getBody().getResponseData());

            }
        }
    }

    @Override
    public CommonClientResponse getCartByUserId(long userId) {
        Cart cart = cartRepository.findByUserId(userId);
        if (null != cart) {
            return CommonUtils.returnCommonClientResponse("Success", "200", "Success", cart);
        } else {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "No Cart Found For given UserId : " + userId, null);
        }
    }
}
