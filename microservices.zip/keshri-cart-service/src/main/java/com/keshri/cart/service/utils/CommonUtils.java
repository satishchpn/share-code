package com.keshri.cart.service.utils;


import com.keshri.cart.service.model.CommonClientResponse;

public class CommonUtils {

    public static CommonClientResponse returnCommonClientResponse(String status, String statusCode, String message, Object responseData) {
        return new CommonClientResponse(status, statusCode, message, responseData);
    }
}
