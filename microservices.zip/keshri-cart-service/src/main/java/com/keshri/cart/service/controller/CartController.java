package com.keshri.cart.service.controller;

import com.keshri.cart.service.model.CommonClientRequest;
import com.keshri.cart.service.model.CommonClientResponse;
import com.keshri.cart.service.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class CartController {


    Logger logger = LoggerFactory.getLogger(CartController.class);

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/addToCart")
    public ResponseEntity<CommonClientResponse> addToCart(@RequestBody CommonClientRequest commonClientRequest) {
        logger.info("CartService - addToCart(-) Called");
        CommonClientResponse response = cartService.addToCart(commonClientRequest);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/doShopping")
    public ResponseEntity<CommonClientResponse> doShopping(@RequestBody CommonClientRequest commonClientRequest) {
        logger.info("CartService - doShopping(-) Called");
        CommonClientResponse response = cartService.doShopping(commonClientRequest);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getCartByUserId/{userId}")
    public ResponseEntity<CommonClientResponse> getCartByUserId(@PathVariable long userId) {
        logger.info("UserService - getCartByUserId(-) Called");
        CommonClientResponse response = cartService.getCartByUserId(userId);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
