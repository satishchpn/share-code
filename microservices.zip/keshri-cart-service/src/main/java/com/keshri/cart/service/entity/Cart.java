package com.keshri.cart.service.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "cart_tbl")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cart implements Serializable {

    @Id
    private long cartId;
    private String itemName;
    private long itemPrice;
    private long userId;
    private String userName;
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

}
