package com.keshri.cart.service.feignClient;


import com.keshri.cart.service.model.CommonClientRequest;
import com.keshri.cart.service.model.CommonClientResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("keshri-payment-service")
public interface PaymentServiceClient {

    @PostMapping("/paymentapi/doPayment")
    ResponseEntity<CommonClientResponse> doPayment(@RequestBody CommonClientRequest request);
}