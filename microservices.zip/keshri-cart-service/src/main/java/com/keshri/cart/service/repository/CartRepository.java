package com.keshri.cart.service.repository;

import com.keshri.cart.service.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

    List<Cart> findByCartIdAndUserId(long cartId, long userId);

    Cart findByUserId(long userId);
}
