#1 Registry MicroService
Service Registry (keshri-service-registry) => To register all the MicroServices running on 8761

#2 Api Gateway MicroService
API Gateway (keshri-api-gateway) => To Route the Calls to the respective MicroServices running on 8080

#3 Config Server MicroService
Config Server (keshri-config-server) => To Store Common properties of all the MicroServices running on 9090

#4 User MicroService
User MicroService (keshri-user-service) => To Store User Details running on 9091

#5 Cart MicroService
Cart MicroService(keshri-cart-service) => To Store cart details along with user id and name running on 9092

#6 Payment MicroService
Payment MicroService (keshri-payment-service) => To Store payment details along with user id and name running on 9093

#Access H2 DB
	To Access H2 Console After Starting server type <host>:<port>/h2-console
	JDBC URL:jdbc:h2:mem:testdb -> Connect
	Add Some data to user table through api and see the data in h2 db



#Steps To Run The Application
----------------------------------------------
1.	Start Registry Server	->	http://localhost:8761/
2.	Start Config Server		->	9090	->	Registered on Registry Server		
3.	Start Gateway Sever		->	8080	->	Registered on Registry Server			
4.	Start User Service		->	9091	->	Registered on Registry Server
5.	Start Cart Service		->	9092	->	Registered on Registry Server	
6.	Start Payment Service	->	9093	->	Registered on Registry Server


	



#7 MicroServices
Zipkin MicroSrvice (keshri-zipkin-service) => To Trace the MicroServices calls




