package com.keshri.payment.service.keshri.controller;

import com.keshri.payment.service.keshri.model.CommonClientRequest;
import com.keshri.payment.service.keshri.model.CommonClientResponse;
import com.keshri.payment.service.keshri.service.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class PaymentController {

    Logger logger = LoggerFactory.getLogger(PaymentController.class);

    final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/doPayment")
    public ResponseEntity<CommonClientResponse> doPayment(@RequestBody CommonClientRequest commonClientRequest) {
        logger.info("PaymentService - doPayment(-) Called");
        CommonClientResponse response = paymentService.doPayment(commonClientRequest);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getPaymentByUserId/{userId}")
    public ResponseEntity<CommonClientResponse> getPaymentByUserId(@PathVariable long userId) {
        logger.info("UserService - getUserById(-) Called");
        CommonClientResponse response = paymentService.getPaymentByUserId(userId);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
