package com.keshri.payment.service.keshri.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserPaymentDetails {

    private long userId;

    private String userName;

    private String itemName;

    private long transactionAmount;

    private Date transactionDate;

}
