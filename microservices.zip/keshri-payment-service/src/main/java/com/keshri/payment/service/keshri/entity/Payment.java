package com.keshri.payment.service.keshri.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "payment_tbl")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Payment implements Serializable {

    @Id
    private long paymentId;
    @Temporal(TemporalType.TIMESTAMP)
    private Date transactionDate;
    private long transactionAmount;
    private long userId;
    private String userName;
}
