package com.keshri.payment.service.keshri.utils;


import com.keshri.payment.service.keshri.model.CommonClientResponse;

public class CommonUtils {

    public static CommonClientResponse returnCommonClientResponse(String status, String statusCode, String message, Object responseData) {
        return new CommonClientResponse(status, statusCode, message, responseData);
    }
}
