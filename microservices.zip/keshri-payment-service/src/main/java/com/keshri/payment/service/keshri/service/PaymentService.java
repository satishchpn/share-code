package com.keshri.payment.service.keshri.service;

import com.keshri.payment.service.keshri.model.CommonClientRequest;
import com.keshri.payment.service.keshri.model.CommonClientResponse;

public interface PaymentService {
    CommonClientResponse doPayment(CommonClientRequest payment);

    CommonClientResponse getPaymentByUserId(long userId);
}
