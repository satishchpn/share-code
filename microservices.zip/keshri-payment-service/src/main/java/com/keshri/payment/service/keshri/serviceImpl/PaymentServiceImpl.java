package com.keshri.payment.service.keshri.serviceImpl;

import com.keshri.payment.service.keshri.entity.Payment;
import com.keshri.payment.service.keshri.model.CommonClientRequest;
import com.keshri.payment.service.keshri.model.CommonClientResponse;
import com.keshri.payment.service.keshri.repository.PaymentRepository;
import com.keshri.payment.service.keshri.service.PaymentService;
import com.keshri.payment.service.keshri.utils.CommonUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentServiceImpl(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @Override
    public CommonClientResponse doPayment(CommonClientRequest commonClientRequest) {
        commonClientRequest.setTransactionAmount(53000);
        Payment payment = new Payment(RandomUtils.nextInt(), new Date(), commonClientRequest.getTransactionAmount(), commonClientRequest.getUserId(), commonClientRequest.getUserName());
        CommonClientResponse response = new CommonClientResponse();
        if (null != paymentRepository.save(payment)) {
            return CommonUtils.returnCommonClientResponse("Success", "200", "Payment Successful for this transaction of UserId : " + commonClientRequest.getUserId(), payment);
        } else {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "Payment Failed for this transaction of UserId : " + commonClientRequest.getUserId(), null);
        }
    }

    @Override
    public CommonClientResponse getPaymentByUserId(long userId) {
        Payment payment = paymentRepository.findByUserId(userId);
        if (null != payment) {
            return CommonUtils.returnCommonClientResponse("Success", "200", "Success", payment);
        } else {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "No Payment Found For given UserId : " + userId, null);
        }
    }
}
