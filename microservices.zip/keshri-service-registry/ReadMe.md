#1 MicroSrvice
Service Registry(keshri-service-registry) => To register all the microservices
Dependencies -> Eureka Server

#2 MicroSrvice
User Microservice(keshri-user-service) => To Store User Deatils
Dependencies -> Web , Eureka Client ,H2 DB, Spring Data JPA , Lombok ,DevTools

To Access H2 Console After Starting server type <host>:<port>/h2-console
JDBC URL:jdbc:h2:mem:testdb -> Connect
Add Some data to user table through api and see the data in h2 db

#3 MicroSrvice
Cart MicroSrvice(keshri-cart-service) => To Store cart details along with user id and name
Dependencies -> Eureka Client ,Web

#4 MicroSrvice
Payment MicroSrvice(keshri-payment-service) => To Store payment details along with user id and name
Dependencies -> Eureka Client ,Web

#4 MicroSrvice
API Gateway(keshri-api-gateway) => To Route the Calls to the respective MicroServices
Dependencies -> Eureka Client ,Web

#6 MicroSrvice
Config Server(keshri-config-server) => To Store Common properties of all the MicroServices
Dependencies -> Eureka Client ,Web

#7 MicroServices
Zipkin MicroSrvice(keshri-zipkin-service) => To Trace the MicroServices calls
Dependencies -> Eureka Client ,Web



