package com.keshri.user.service.controller;

import com.keshri.user.service.entity.User;
import com.keshri.user.service.model.CommonClientRequest;
import com.keshri.user.service.model.CommonClientResponse;
import com.keshri.user.service.service.UserService;
import com.keshri.user.service.utils.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {

    Logger logger = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;

    @Value("${third.party.api.service.uri}")
    private String thirdPartUrl;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/checkProperties")
    public ResponseEntity<CommonClientResponse> checkProperties() {
        logger.info("UserService - checkProperties(-) Called");
        CommonClientResponse response = CommonUtils.returnCommonClientResponse(null, null, "Hello Third Party Uri from Git Config Server is  : " + thirdPartUrl, null);
        return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
    }

    @PostMapping("/addUser")
    public ResponseEntity<CommonClientResponse> addUser(@RequestBody User user) {
        logger.info("UserService - addUser(-) Called");
        CommonClientResponse response = userService.addUser(user);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getUserById/{userId}")
    public ResponseEntity<CommonClientResponse> getUserById(@PathVariable long userId) {
        logger.info("UserService - getUserById(-) Called");
        CommonClientResponse response = userService.getUserById(userId);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/addToCart")
    public ResponseEntity<CommonClientResponse> addToCart(@RequestBody CommonClientRequest request) {
        logger.info("UserService - addToCart(-) Called");
        CommonClientResponse response = userService.addToCart(request.getUserId());
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/doShopping")
    public ResponseEntity<CommonClientResponse> doShopping(@RequestBody CommonClientRequest request) {
        logger.info("UserService - doShopping(-) Called");
        CommonClientResponse response = userService.doShopping(request);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getUserShoppingDetails/{userId}")
    public ResponseEntity<CommonClientResponse> getUserShoppingDetails(@PathVariable long userId) {
        logger.info("UserService - getUserShoppingDetails(-) Called");
        CommonClientResponse response = userService.getUserShoppingDetails(userId);
        if (null != response.getStatusCode() && response.getStatusCode().equals("200")) {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<CommonClientResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
