package com.keshri.user.service.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "user_tbl")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User implements Serializable {

    @Id
    private long userId;
    private String userName;
    private String phoneNo;
    private String address;
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
}
