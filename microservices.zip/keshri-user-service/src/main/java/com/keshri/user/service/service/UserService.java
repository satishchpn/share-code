package com.keshri.user.service.service;

import com.keshri.user.service.entity.User;
import com.keshri.user.service.model.CommonClientRequest;
import com.keshri.user.service.model.CommonClientResponse;

public interface UserService {

    CommonClientResponse addUser(User user);

    CommonClientResponse getUserById(long userId);

    CommonClientResponse addToCart(long userId);

    CommonClientResponse doShopping(CommonClientRequest request);

    CommonClientResponse getUserShoppingDetails(long userId);
}