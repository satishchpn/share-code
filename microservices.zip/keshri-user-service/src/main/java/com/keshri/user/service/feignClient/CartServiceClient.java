package com.keshri.user.service.feignClient;

import com.keshri.user.service.model.CommonClientRequest;
import com.keshri.user.service.model.CommonClientResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("keshri-cart-service")
public interface CartServiceClient {

    @PostMapping("/cartapi/addToCart")
    public ResponseEntity<CommonClientResponse> addToCart(@RequestBody CommonClientRequest request);

    @GetMapping("/cartapi/getCartByUserId/{userId}")
    public ResponseEntity<CommonClientResponse> getCartByUserId(@PathVariable long userId);


    @PostMapping("/cartapi/doShopping")
    public ResponseEntity<CommonClientResponse> doShopping(@RequestBody CommonClientRequest request);

}