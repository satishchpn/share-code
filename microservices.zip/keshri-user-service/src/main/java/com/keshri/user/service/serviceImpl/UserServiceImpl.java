package com.keshri.user.service.serviceImpl;

import com.keshri.user.service.entity.User;
import com.keshri.user.service.feignClient.CartServiceClient;
import com.keshri.user.service.feignClient.PaymentServiceClient;
import com.keshri.user.service.model.CommonClientRequest;
import com.keshri.user.service.model.CommonClientResponse;
import com.keshri.user.service.repository.UserRepository;
import com.keshri.user.service.service.UserService;
import com.keshri.user.service.utils.CommonUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserServiceImpl implements UserService {

    Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;

    private final CartServiceClient cartServiceClient;

    private final PaymentServiceClient paymentServiceClient;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, CartServiceClient cartServiceClient, PaymentServiceClient paymentServiceClient) {
        this.userRepository = userRepository;
        this.cartServiceClient = cartServiceClient;
        this.paymentServiceClient = paymentServiceClient;
    }


    @Override
    public CommonClientResponse addUser(User user) {
        user.setCreationDate(new Date());
        user.setUserId(RandomUtils.nextInt());
        if (null != userRepository.save(user)) {
            return CommonUtils.returnCommonClientResponse("Success", "200", "User Added Successfully", user);
        } else {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "Failed to add User", null);
        }
    }

    @Override
    public CommonClientResponse getUserById(long userId) {
        User user = userRepository.findByUserId(userId);
        if (null != user) {
            return CommonUtils.returnCommonClientResponse("Success", "200", "Success", user);
        } else {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "No User Found For given UserId : " + userId, null);
        }
    }

    @Override
    public CommonClientResponse addToCart(long userId) {
        logger.info("UserServiceImpl - fetching userById");
        User user = (User) getUserById(userId).getResponseData();
        CommonClientResponse commonClientResponse = new CommonClientResponse();
        if (null == user) {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "User Not Found with UserId :" + userId, null);
        } else {
            logger.info("UserServiceImpl - CartServiceClient.addToCart(-) Calling");
            CommonClientRequest request = new CommonClientRequest(userId, user.getUserName(), 0, 0);
            ResponseEntity<CommonClientResponse> response = cartServiceClient.addToCart(request);
            logger.info("UserServiceImpl - CartServiceClient.addToCart(-) Response : " + response.getBody().getMessage());
            if (null != response.getBody().getStatusCode() && response.getBody().getStatusCode().equals("200")) {
                return CommonUtils.returnCommonClientResponse("Success", "200", response.getBody().getMessage(), response.getBody().getResponseData());
            } else {
                return CommonUtils.returnCommonClientResponse("Failed", "500", response.getBody().getMessage(), response.getBody().getResponseData());

            }
        }
    }


    @Override
    public CommonClientResponse doShopping(CommonClientRequest commonClientRequest) {
        logger.info("UserServiceImpl - fetching userById");
        User user = (User) getUserById(commonClientRequest.getUserId()).getResponseData();
        if (null == user) {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "User Not Found with UserId :" + commonClientRequest.getUserId(), null);
        } else {
            logger.info("UserServiceImpl - CartServiceClient.doShopping(-) Calling");
            commonClientRequest.setUserName(user.getUserName());
            ResponseEntity<CommonClientResponse> response = cartServiceClient.doShopping(commonClientRequest);
            logger.info("UserServiceImpl - CartServiceClient.doShopping(-) Response : " + response.getBody().getMessage());
            if (null != response.getBody().getStatusCode() && response.getBody().getStatusCode().equals("200")) {
                return CommonUtils.returnCommonClientResponse("Success", "200", response.getBody().getMessage(), response.getBody().getResponseData());
            } else {
                return CommonUtils.returnCommonClientResponse("Failed", "500", response.getBody().getMessage(), response.getBody().getResponseData());

            }
        }
    }

    @Override
    public CommonClientResponse getUserShoppingDetails(long userId) {
        logger.info("UserServiceImpl - fetching userById");
        User user = (User) getUserById(userId).getResponseData();
        if (null == user) {
            return CommonUtils.returnCommonClientResponse("Failed", "500", "User Not Found with UserId :" + userId, null);
        } else {
            logger.info("UserServiceImpl - CartServiceClient.getCartByUserId(-) Calling");
            CommonClientRequest request = new CommonClientRequest(userId, user.getUserName(), 0, 0);
            ResponseEntity<CommonClientResponse> cartResponse = cartServiceClient.getCartByUserId(request.getUserId());
            logger.info("UserServiceImpl - CartServiceClient.getCartByUserId(-) Response : " + cartResponse.getBody().getMessage());
            if (null != cartResponse.getBody().getStatusCode() && cartResponse.getBody().getStatusCode().equals("200")) {
                ResponseEntity<CommonClientResponse> paymentResponse = paymentServiceClient.getPaymentByUserId(request.getUserId());
                if (null != cartResponse.getBody().getStatusCode() && cartResponse.getBody().getStatusCode().equals("200")) {
                    return CommonUtils.returnCommonClientResponse("Success", "200", paymentResponse.getBody().getMessage(), cartResponse.getBody().getResponseData());
                } else {
                    return CommonUtils.returnCommonClientResponse("Failed", "500", paymentResponse.getBody().getMessage(), paymentResponse.getBody().getResponseData());

                }
            } else {
                return CommonUtils.returnCommonClientResponse("Failed", "500", cartResponse.getBody().getMessage(), cartResponse.getBody().getResponseData());

            }
        }
    }
}
