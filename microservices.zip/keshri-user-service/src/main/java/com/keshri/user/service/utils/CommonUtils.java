package com.keshri.user.service.utils;

import com.keshri.user.service.model.CommonClientResponse;

public class CommonUtils {

    public static CommonClientResponse returnCommonClientResponse(String status, String statusCode, String message, Object responseData) {
        return new CommonClientResponse(status, statusCode, message, responseData);
    }
}
