package com.keshri.user.service.feignClient;


import com.keshri.user.service.model.CommonClientResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("keshri-payment-service")
public interface PaymentServiceClient {

    @GetMapping("/paymentapi/getPaymentByUserId/{userId}")
    public ResponseEntity<CommonClientResponse> getPaymentByUserId(@PathVariable long userId);
}