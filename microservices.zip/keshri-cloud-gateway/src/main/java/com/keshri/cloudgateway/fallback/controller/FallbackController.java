package com.keshri.cloudgateway.fallback.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
public class FallbackController {

    @GetMapping("/userServiceFallback")
    public Mono<String> userServiceFallback() {
        return Mono.just("User Service is taking too long to respond..!!Try Again Later");
    }

    @GetMapping("/cartServiceFallback")
    public Mono<String> cartServiceFallback() {
        return Mono.just("Cart Service is taking too long to respond..!!Try Again Later");
    }

    @GetMapping("/paymentServiceFallback")
    public Mono<String> paymentServiceFallback() {
        return Mono.just("Payment Service is taking too long to respond..!!Try Again Later");
    }

}
